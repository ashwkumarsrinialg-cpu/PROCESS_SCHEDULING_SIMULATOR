#!/usr/bin/env python3
"""
android_bench.py — Real Android Hardware Benchmarking Harness
==============================================================
Drives a connected Android device via ADB to collect:
  - cyclictest wakeup-latency histograms (RT tasks)
  - Perfetto frame-timing traces (UI thread scheduling)
  - sysbench CPU throughput
  - /proc/sched_hybrid_stat polling (if hybrid kernel is active)
  - Thermal zone temperatures during load
  - Per-core CPU frequency residency

Prerequisites
-------------
  adb in PATH, device connected with USB debugging enabled.
  On the device (rooted GKI kernel):
    - cyclictest binary at /data/local/tmp/cyclictest
    - sysbench binary at /data/local/tmp/sysbench
    - Perfetto config bundled with this script (written on-device at runtime)

Usage
-----
  # Basic run (auto-detects scheduler):
  python3 android_bench.py --duration 30

  # Compare CFS vs Hybrid (requires two kernel images):
  python3 android_bench.py --compare --duration 60 --output results/

  # Thermal stress test:
  python3 android_bench.py --thermal-sweep --min-temp 40 --max-temp 80

Author: Hybrid Scheduler Research
"""

import subprocess
import time
import json
import os
import sys
import argparse
import statistics
import threading
from datetime import datetime
from pathlib import Path


# ─────────────────────────────────────────────
#  ADB helpers
# ─────────────────────────────────────────────

class ADBDevice:
    """Thin wrapper around adb shell commands."""

    def __init__(self, serial=None, verbose=False):
        self.serial  = serial
        self.verbose = verbose
        self._base   = ["adb"]
        if serial:
            self._base += ["-s", serial]

    def shell(self, cmd, timeout=30, ignore_errors=False):
        full = self._base + ["shell", cmd]
        if self.verbose:
            print(f"  [adb] {cmd}")
        try:
            r = subprocess.run(full, capture_output=True, text=True,
                               timeout=timeout)
            if r.returncode != 0 and not ignore_errors:
                raise RuntimeError(f"adb shell failed: {r.stderr.strip()}")
            return r.stdout.strip()
        except subprocess.TimeoutExpired:
            raise TimeoutError(f"ADB command timed out: {cmd}")

    def push(self, local, remote):
        subprocess.run(self._base + ["push", local, remote], check=True)

    def pull(self, remote, local):
        subprocess.run(self._base + ["pull", remote, local], check=True)

    def root(self):
        subprocess.run(self._base + ["root"], check=True)
        time.sleep(2)

    def check_connected(self):
        r = subprocess.run(self._base + ["get-state"],
                           capture_output=True, text=True, timeout=5)
        return r.returncode == 0 and "device" in r.stdout

    def get_property(self, prop):
        return self.shell(f"getprop {prop}", ignore_errors=True)

    def device_info(self):
        return {
            "model":        self.get_property("ro.product.model"),
            "android_ver":  self.get_property("ro.build.version.release"),
            "kernel":       self.shell("uname -r"),
            "soc":          self.get_property("ro.hardware"),
            "cpu_cores":    int(self.shell("nproc")),
            "scheduler":    self._detect_scheduler(),
        }

    def _detect_scheduler(self):
        """Check if hybrid kernel patch is active."""
        stat = self.shell("cat /proc/sched_hybrid_stat 2>/dev/null",
                          ignore_errors=True)
        if stat and "tau_x1000" in stat:
            return "hybrid"
        # Check kernel config
        cfg = self.shell("zcat /proc/config.gz 2>/dev/null | "
                         "grep SCHED_HYBRID", ignore_errors=True)
        if "CONFIG_SCHED_HYBRID=y" in cfg:
            return "hybrid"
        # Default: check /sys/kernel/debug/sched/features
        feats = self.shell("cat /sys/kernel/debug/sched/features 2>/dev/null",
                           ignore_errors=True)
        if "EEVDF" in feats:
            return "eevdf"
        return "cfs"


# ─────────────────────────────────────────────
#  Thermal monitoring (background thread)
# ─────────────────────────────────────────────

class ThermalMonitor(threading.Thread):
    """
    Polls thermal zones on device every poll_interval seconds.
    Stores readings in self.samples = [(timestamp, {zone: temp_mC}), ...]
    """

    def __init__(self, device, poll_interval=1.0):
        super().__init__(daemon=True)
        self.device        = device
        self.poll_interval = poll_interval
        self.samples       = []
        self._stop_evt     = threading.Event()

    def run(self):
        while not self._stop_evt.is_set():
            try:
                raw = self.device.shell(
                    "for z in /sys/class/thermal/thermal_zone*/; do "
                    "  name=$(cat ${z}type 2>/dev/null); "
                    "  temp=$(cat ${z}temp 2>/dev/null); "
                    "  echo ${name}:${temp}; "
                    "done", ignore_errors=True)
                reading = {}
                for line in raw.splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        try:
                            reading[k.strip()] = int(v.strip())
                        except ValueError:
                            pass
                self.samples.append((time.time(), reading))
            except Exception:
                pass
            self._stop_evt.wait(self.poll_interval)

    def stop(self):
        self._stop_evt.set()

    def cpu_temps(self):
        """Return list of (timestamp, temp_mC) for the dominant CPU zone."""
        out = []
        for ts, zones in self.samples:
            # Prefer cpu-thermal, fallback to first zone with "cpu" in name
            cpu_z = next((v for k, v in zones.items() if "cpu" in k.lower()), None)
            if cpu_z is not None:
                out.append((ts, cpu_z))
        return out

    def peak_cpu_temp(self):
        temps = [t for _, t in self.cpu_temps()]
        return max(temps) if temps else 0

    def mean_cpu_temp(self):
        temps = [t for _, t in self.cpu_temps()]
        return statistics.mean(temps) if temps else 0


# ─────────────────────────────────────────────
#  cyclictest — RT wakeup latency
# ─────────────────────────────────────────────

CYCLICTEST_BINARY = "/data/local/tmp/cyclictest"

def run_cyclictest(device, duration=30, priority=80, affinity=None):
    """
    Run cyclictest on device. Returns dict with:
      min_us, avg_us, max_us, p99_us, histogram (list of (us, count))
    """
    affinity_flag = f"-a {affinity}" if affinity else ""
    cmd = (
        f"taskset -c {affinity or '0'} "
        f"{CYCLICTEST_BINARY} "
        f"--mlockall --smp -p {priority} "
        f"-t 1 -D {duration}s "
        f"-i 1000 --histogram=200 -q "
        f"{affinity_flag} 2>&1"
    )

    print(f"  Running cyclictest for {duration}s …")
    try:
        raw = device.shell(cmd, timeout=duration + 15)
    except TimeoutError:
        print("  WARNING: cyclictest timed out, using partial results")
        raw = ""

    return _parse_cyclictest_output(raw)


def _parse_cyclictest_output(raw):
    """Parse cyclictest histogram output."""
    histogram = []
    min_us = avg_us = max_us = None

    for line in raw.splitlines():
        line = line.strip()
        if line.startswith("#"):
            if "Min Latencies:" in line:
                try:
                    min_us = int(line.split()[-1])
                except (ValueError, IndexError):
                    pass
            elif "Avg Latencies:" in line:
                try:
                    avg_us = int(line.split()[-1])
                except (ValueError, IndexError):
                    pass
            elif "Max Latencies:" in line:
                try:
                    max_us = int(line.split()[-1])
                except (ValueError, IndexError):
                    pass
        elif line and not line.startswith("#"):
            parts = line.split()
            if len(parts) >= 2:
                try:
                    us    = int(parts[0])
                    count = int(parts[1])
                    if count > 0:
                        histogram.append((us, count))
                except ValueError:
                    pass

    # Compute P99 from histogram
    p99_us = _histogram_percentile(histogram, 99)

    return {
        "min_us":    min_us or 0,
        "avg_us":    avg_us or 0,
        "max_us":    max_us or 0,
        "p99_us":    p99_us,
        "histogram": histogram,
        "raw":       raw,
    }


def _histogram_percentile(histogram, pct):
    if not histogram:
        return 0
    total  = sum(c for _, c in histogram)
    target = total * pct / 100
    cumul  = 0
    for us, count in sorted(histogram):
        cumul += count
        if cumul >= target:
            return us
    return histogram[-1][0]


# ─────────────────────────────────────────────
#  sysbench — CPU throughput
# ─────────────────────────────────────────────

SYSBENCH_BINARY = "/data/local/tmp/sysbench"

def run_sysbench(device, threads=None, duration=20):
    """
    Run sysbench CPU benchmark. Returns events_per_second.
    """
    if threads is None:
        threads = int(device.shell("nproc"))

    cmd = (
        f"{SYSBENCH_BINARY} cpu "
        f"--cpu-max-prime=20000 "
        f"--threads={threads} "
        f"--time={duration} run 2>&1"
    )

    print(f"  Running sysbench ({threads} threads, {duration}s) …")
    try:
        raw = device.shell(cmd, timeout=duration + 30)
    except TimeoutError:
        print("  WARNING: sysbench timed out")
        return {"events_per_sec": 0, "threads": threads, "raw": ""}

    eps = 0.0
    for line in raw.splitlines():
        if "events per second:" in line:
            try:
                eps = float(line.split(":")[-1].strip())
            except ValueError:
                pass

    return {"events_per_sec": eps, "threads": threads, "raw": raw}


# ─────────────────────────────────────────────
#  Perfetto frame-timing trace
# ─────────────────────────────────────────────

PERFETTO_CONFIG = """
buffers: {{
    size_kb: 65536
    fill_policy: DISCARD
}}
data_sources: {{
    config {{
        name: "linux.ftrace"
        ftrace_config {{
            ftrace_events: "sched/sched_switch"
            ftrace_events: "sched/sched_wakeup"
            ftrace_events: "sched/sched_wakeup_new"
            ftrace_events: "power/cpu_frequency"
            ftrace_events: "power/cpu_idle"
            ftrace_events: "thermal/thermal_temperature"
            atrace_categories: "view"
            atrace_categories: "wm"
            atrace_categories: "input"
            atrace_categories: "gfx"
            atrace_apps: "{app_package}"
        }}
    }}
}}
data_sources: {{
    config {{
        name: "linux.process_stats"
        process_stats_config {{
            scan_all_processes_on_start: true
            proc_stats_poll_ms: 1000
        }}
    }}
}}
duration_ms: {duration_ms}
"""

def run_perfetto_trace(device, app_package="com.android.systemui",
                       duration_ms=10000, output_path="/tmp/trace.perfetto-trace"):
    """
    Capture a Perfetto trace and pull it to output_path.
    Returns path to local trace file (open with ui.perfetto.dev).
    """
    config_str = PERFETTO_CONFIG.format(
        app_package=app_package, duration_ms=duration_ms)

    config_remote = "/data/local/tmp/hybrid_perfetto.pbtx"
    trace_remote  = "/data/local/tmp/hybrid.perfetto-trace"

    # Push config
    local_cfg = "/tmp/hybrid_perfetto.pbtx"
    with open(local_cfg, "w") as f:
        f.write(config_str)
    device.push(local_cfg, config_remote)

    print(f"  Capturing Perfetto trace ({duration_ms/1000:.0f}s) …")
    device.shell(
        f"perfetto -c {config_remote} --txt -o {trace_remote}",
        timeout=duration_ms // 1000 + 30)

    # Pull trace
    device.pull(trace_remote, output_path)
    print(f"  Trace saved to {output_path}")
    print(f"  → Open at https://ui.perfetto.dev  (drag-and-drop the file)")
    return output_path


# ─────────────────────────────────────────────
#  /proc/sched_hybrid_stat reader
# ─────────────────────────────────────────────

def read_hybrid_stat(device):
    """
    Poll /proc/sched_hybrid_stat and return parsed dict.
    Returns None if the file doesn't exist (non-hybrid kernel).
    """
    raw = device.shell("cat /proc/sched_hybrid_stat 2>/dev/null",
                       ignore_errors=True)
    if not raw or "tau_x1000" not in raw:
        return None

    result = {}
    for line in raw.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            try:
                result[k.strip()] = int(v.strip())
            except ValueError:
                result[k.strip()] = v.strip()
    return result


def poll_hybrid_stat(device, duration=30, interval=1.0):
    """
    Poll hybrid stat every interval seconds for duration seconds.
    Returns list of (timestamp, stat_dict).
    """
    samples = []
    end_t   = time.time() + duration

    while time.time() < end_t:
        stat = read_hybrid_stat(device)
        if stat:
            samples.append((time.time(), stat))
        time.sleep(interval)

    return samples


# ─────────────────────────────────────────────
#  CPU frequency residency
# ─────────────────────────────────────────────

def read_freq_residency(device, cpu=0):
    """
    Read /sys/devices/system/cpu/cpuN/cpufreq/stats/time_in_state.
    Returns dict {freq_kHz: time_cs} (centiseconds in each state).
    """
    raw = device.shell(
        f"cat /sys/devices/system/cpu/cpu{cpu}/cpufreq/stats/time_in_state"
        f" 2>/dev/null", ignore_errors=True)

    result = {}
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) == 2:
            try:
                result[int(parts[0])] = int(parts[1])
            except ValueError:
                pass
    return result


# ─────────────────────────────────────────────
#  Full benchmark suite
# ─────────────────────────────────────────────

class BenchmarkSuite:

    def __init__(self, device, output_dir="bench_results", duration=30):
        self.device     = device
        self.output_dir = Path(output_dir)
        self.duration   = duration
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.results    = {}

    def _ts(self):
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def run_all(self, skip_perfetto=False, app_package="com.android.systemui"):
        print("\n" + "="*60)
        print("  Android Hardware Benchmark Suite")
        print("="*60)

        # Device info
        info = self.device.device_info()
        self.results["device"] = info
        print(f"\n  Device : {info['model']}")
        print(f"  Android: {info['android_ver']}")
        print(f"  Kernel : {info['kernel']}")
        print(f"  Sched  : {info['scheduler'].upper()}")

        # Start thermal monitor
        thermal = ThermalMonitor(self.device)
        thermal.start()

        # 1. cyclictest
        print("\n[1/4] RT Wakeup Latency (cyclictest)")
        ct = run_cyclictest(self.device, duration=self.duration)
        self.results["cyclictest"] = ct
        print(f"  Min: {ct['min_us']} µs | "
              f"Avg: {ct['avg_us']} µs | "
              f"P99: {ct['p99_us']} µs | "
              f"Max: {ct['max_us']} µs")

        # 2. sysbench
        print("\n[2/4] CPU Throughput (sysbench)")
        sb = run_sysbench(self.device, duration=self.duration)
        self.results["sysbench"] = sb
        print(f"  Events/sec: {sb['events_per_sec']:.1f}")

        # 3. Hybrid stat (if applicable)
        print("\n[3/4] Hybrid Scheduler Stats")
        if info["scheduler"] == "hybrid":
            hstat_samples = poll_hybrid_stat(
                self.device, duration=min(15, self.duration))
            self.results["hybrid_stat"] = hstat_samples
            if hstat_samples:
                last = hstat_samples[-1][1]
                print(f"  tau:   {last.get('tau_x1000', 'N/A')} / 1000")
                print(f"  alpha: {last.get('alpha_x1000', 'N/A')} / 1000")
                print(f"  Thermal throttle events: "
                      f"{last.get('thermal_throttle', 'N/A')}")
        else:
            print("  (Hybrid kernel not detected — skipping stat poll)")
            self.results["hybrid_stat"] = []

        # 4. Perfetto
        print("\n[4/4] Frame-Timing Trace (Perfetto)")
        if skip_perfetto:
            print("  (skipped — use --perfetto to enable)")
        else:
            trace_path = self.output_dir / f"trace_{self._ts()}.perfetto-trace"
            try:
                run_perfetto_trace(
                    self.device,
                    app_package=app_package,
                    duration_ms=self.duration * 1000,
                    output_path=str(trace_path))
                self.results["perfetto_trace"] = str(trace_path)
            except Exception as e:
                print(f"  WARNING: Perfetto failed: {e}")
                self.results["perfetto_trace"] = None

        # Stop thermal monitor
        thermal.stop()
        thermal.join(timeout=2)
        self.results["thermal"] = {
            "samples": thermal.samples[-50:],   # last 50 readings
            "peak_cpu_mC":  thermal.peak_cpu_temp(),
            "mean_cpu_mC":  int(thermal.mean_cpu_temp()),
        }
        print(f"\n  Peak CPU temp: {thermal.peak_cpu_temp()/1000:.1f} °C")
        print(f"  Mean CPU temp: {thermal.mean_cpu_temp()/1000:.1f} °C")

        # Save JSON results
        results_path = self.output_dir / f"bench_{self._ts()}.json"
        _save_results(self.results, str(results_path))
        print(f"\n  Results saved to {results_path}")

        return self.results


def _save_results(results, path):
    """JSON-serialise results, converting non-serialisable types."""
    def default(obj):
        if hasattr(obj, "__dict__"):
            return obj.__dict__
        return str(obj)

    with open(path, "w") as f:
        json.dump(results, f, indent=2, default=default)


# ─────────────────────────────────────────────
#  CLI
# ─────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="Android hardware benchmark harness for hybrid scheduler research")
    p.add_argument("--serial",     help="ADB device serial (default: first connected)")
    p.add_argument("--duration",   type=int, default=30,
                   help="Benchmark duration in seconds (default: 30)")
    p.add_argument("--output",     default="bench_results",
                   help="Output directory (default: bench_results/)")
    p.add_argument("--perfetto",   action="store_true",
                   help="Capture Perfetto trace (requires device running target app)")
    p.add_argument("--app",        default="com.android.systemui",
                   help="App package for Perfetto atrace")
    p.add_argument("--verbose",    action="store_true")
    p.add_argument("--dry-run",    action="store_true",
                   help="Print what would be run without executing (no device needed)")
    return p.parse_args()


def main():
    args = parse_args()

    if args.dry_run:
        print("DRY RUN — commands that would execute:")
        print(f"  adb root")
        print(f"  adb shell {CYCLICTEST_BINARY} --mlockall --smp -p 80 "
              f"-t 1 -D {args.duration}s -i 1000 --histogram=200 -q")
        print(f"  adb shell {SYSBENCH_BINARY} cpu --cpu-max-prime=20000 "
              f"--threads=$(nproc) --time={args.duration} run")
        print(f"  adb shell cat /proc/sched_hybrid_stat")
        if args.perfetto:
            print(f"  adb shell perfetto -c /data/local/tmp/hybrid_perfetto.pbtx "
                  f"--txt -o /data/local/tmp/hybrid.perfetto-trace")
        print("\nPush binaries first:")
        print(f"  adb push cyclictest {CYCLICTEST_BINARY}")
        print(f"  adb push sysbench   {SYSBENCH_BINARY}")
        return

    device = ADBDevice(serial=args.serial, verbose=args.verbose)

    if not device.check_connected():
        print("ERROR: No Android device connected via ADB.")
        print("  Connect a device and enable USB Debugging, then retry.")
        sys.exit(1)

    try:
        device.root()
    except subprocess.CalledProcessError:
        print("WARNING: Could not get root — some benchmarks may be limited.")

    suite = BenchmarkSuite(device, output_dir=args.output,
                           duration=args.duration)
    suite.run_all(skip_perfetto=not args.perfetto, app_package=args.app)


if __name__ == "__main__":
    main()
