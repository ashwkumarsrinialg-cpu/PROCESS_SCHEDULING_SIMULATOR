# Hybrid EEVDF+MLFQ Scheduler — Research Repository

A research prototype demonstrating a hardware-grounded hybrid CPU scheduler
for mobile Linux, with three integrated components:

---

## Components

### 1. `scheduler_sim.py` — Hardware-Informed Simulator

Discrete-event simulator with an optional **hardware fidelity mode** that
injects real-world overhead modelled from Pixel 7 (Tensor G2) measurements:

| Model                   | Source                                          |
|-------------------------|-------------------------------------------------|
| IRQ jitter              | cyclictest histograms (Poisson + Exp service)   |
| Context-switch cost     | `perf stat` on Cortex-A55 / X3                 |
| cpufreq ramp-up lag     | `/sys/devices/system/cpu/*/cpufreq/stats/`      |
| big.LITTLE capacities   | `arch_scale_cpu_capacity()` (Pixel 7 values)    |
| Thermal scaling τ(T)    | Monsoon power traces + thermalzone readings     |

```bash
# Standard mode (fast Monte Carlo):
python3 scheduler_sim.py --n-runs 200 --n-procs 120

# Hardware-fidelity mode (adds noise model):
python3 scheduler_sim.py --hw-fidelity --n-runs 100
```

**Outputs:** 9 publication-quality plots in `plots/`

---

### 2. `android_bench/android_bench.py` — Android Hardware Benchmarking

ADB-driven benchmark harness for real Android devices:

| Benchmark         | Tool          | What it measures                           |
|-------------------|---------------|--------------------------------------------|
| RT wakeup latency | cyclictest    | Min / Avg / P99 / Max latency histogram    |
| CPU throughput    | sysbench      | Events/sec (multi-threaded)                |
| Frame timing      | Perfetto      | `sched_switch` + `gfx` trace for janks     |
| Hybrid stats      | `/proc/sched_hybrid_stat` | τ, α, tier demotions          |
| Thermal           | Background poller | Per-zone temps every 1 s               |

```bash
# Dry-run (see what would execute, no device needed):
python3 android_bench/android_bench.py --dry-run

# Full run (device must be connected via ADB, rooted):
python3 android_bench/android_bench.py --duration 60 --perfetto

# Push required binaries first:
adb push cyclictest /data/local/tmp/cyclictest
adb push sysbench   /data/local/tmp/sysbench
```

Results saved as `bench_results/bench_<timestamp>.json`.

---

### 3. `validation/hardware_validation.py` — Sim-to-Real Validation

Bridges simulator predictions with hardware measurements:

- **CDF comparison**: cyclictest latency histogram vs simulator P(wait ≤ t)
- **τ(T) overlay**: kernel `/proc/sched_hybrid_stat` vs analytical smooth-step
- **Scatter plots**: per-metric sim vs hw with relative error annotation
- **Validation report**: `validation_report.md` with gap analysis and recommendations

```bash
# Validate against a captured bench result:
python3 validation/hardware_validation.py \
    --bench bench_results/bench_20260101_120000.json

# Sim-only robustness check (no device needed):
python3 validation/hardware_validation.py --sim-only --n-runs 100

# Full pipeline (runs bench + validates in one step):
python3 validation/hardware_validation.py --device --duration 60
```

---

### 4. `kernel_patch/0001-sched-Add-hybrid-EEVDF-MLFQ-mobile-scheduler.patch`

A prototype Linux kernel patch (targets 6.6.x GKI):

| Feature              | Kernel implementation                                      |
|----------------------|------------------------------------------------------------|
| MLFQ tiers           | `hybrid_entity.tier` embedded in `task_struct`            |
| Urgency bias         | `hybrid_vdeadline()` with `alpha` sysctl                  |
| Thermal scaling      | `hybrid_update_tau()` → `thermal_zone_get_temp()`         |
| big.LITTLE capacity  | `arch_scale_cpu_capacity()` in vdeadline computation      |
| Demotion / promotion | `hybrid_task_tick()` + `hybrid_enqueue_task()`            |
| Stats                | `/proc/sched_hybrid_stat`                                  |
| Tuning               | `/proc/sys/kernel/sched_hybrid_alpha`                     |

```bash
# Apply to a 6.6.x kernel tree:
cd /path/to/linux-6.6.x
git apply hybrid_scheduler/kernel_patch/0001-sched-Add-hybrid-EEVDF-MLFQ-mobile-scheduler.patch

# Enable in kernel config:
make menuconfig   # → General setup → Hybrid EEVDF+MLFQ mobile scheduler

# Build and flash to Android device (Pixel 7 example):
make -j$(nproc) ARCH=arm64 Image.lz4
# Flash via fastboot or Android GKI boot image packing
```

> **WARNING**: Research prototype. Do not use in production kernels.

---

## Sim-to-Real Gap

The `hw_fidelity_delta.png` plot shows how much each hardware overhead source
shifts simulator metrics. Expected gaps on Pixel 7:

| Source              | Avg-wait delta | P95-wait delta |
|---------------------|----------------|----------------|
| IRQ jitter          | +0.02 ms       | +0.1 ms        |
| Context-switch cost | +0.15 ms       | +0.4 ms        |
| cpufreq ramp-up     | +0.8 ms        | +2.5 ms        |
| big.LITTLE capacity | −5% throughput | —              |

---

## File Map

```
hybrid_scheduler/
├── scheduler_sim.py                    ← Main simulator (run this)
├── android_bench/
│   └── android_bench.py               ← ADB benchmark harness
├── validation/
│   └── hardware_validation.py         ← Sim-to-real validation
├── kernel_patch/
│   └── 0001-sched-Add-hybrid-...patch ← Linux kernel patch
└── plots/                             ← Generated figures
    ├── stat_comparison.png
    ├── hw_fidelity_delta.png          ← NEW: hardware noise impact
    ├── sensitivity_alpha.png
    ├── sensitivity_temperature.png
    ├── linux_eevdf_params.png
    ├── per_class_metrics.png
    ├── scalability.png
    ├── sim_robustness.png             ← NEW: burst-scale validation
    └── *_allocation_tl.png            ← Gantt charts
```
