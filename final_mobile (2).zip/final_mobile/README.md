# Hybrid EEVDF+MLFQ Scheduler — Research Repository

A research prototype demonstrating a hardware-grounded hybrid CPU scheduler
for mobile Linux, with three integrated components:

---

## Components

### 1. `scheduler_sim.py` — Hardware-Informed Simulator

Discrete-event simulator with an optional **hardware fidelity mode** that
injects real-world overhead modelled from Pixel 7 (Tensor G2) measurements:

| Model                   | Source                                          |
|-------------------------|-------------------------------------------------|
| IRQ jitter              | cyclictest histograms (Poisson + Exp service)   |
| Context-switch cost     | `perf stat` on Cortex-A55 / X3                 |
| cpufreq ramp-up lag     | `/sys/devices/system/cpu/*/cpufreq/stats/`      |
| big.LITTLE capacities   | `arch_scale_cpu_capacity()` (Pixel 7 values)    |
| Thermal scaling τ(T)    | Monsoon power traces + thermalzone readings     |

```bash
# Standard mode (fast Monte Carlo):
python3 scheduler_sim.py --n-runs 200 --n-procs 120

# Hardware-fidelity mode (adds noise model):
python3 scheduler_sim.py --hw-fidelity --n-runs 100

Outputs: 9 publication-quality plots used in the paper.

2. android_bench/android_bench.py — Android Hardware Benchmarking
ADB-driven benchmark harness for real Android devices.

3. validation/hardware_validation.py — Sim-to-Real Validation
Bridges simulator predictions with hardware measurements.

4. Kernel Patch (inside final_mobile.zip)
Prototype Linux kernel patch for 6.6.x GKI implementing the Hybrid EEVDF+MLFQ scheduler.
WARNING: Research prototype. Do not use in production.

Sim-to-Real Gap
The hw_fidelity_delta.png plot shows the impact of hardware noise sources.
Expected gaps on Pixel 7 are documented in the paper.

File Map
text.
├── paper.pdf
├── scheduler_sim.py
├── final_mobile.zip
├── plots/
│   ├── stat_comparison.png
│   ├── hw_fidelity_delta.png
│   ├── sensitivity_alpha.png
│   ├── sensitivity_temperature.png
│   ├── linux_eevdf_params.png
│   ├── per_class_metrics.png
│   ├── scalability.png
│   ├── sim_robustness.png
│   └── *_allocation_tl.png
└── README.md
Reproducing the Paper Results
Bash# Generate all figures
python3 scheduler_sim.py --n-runs 200 --n-procs 120 --hw-fidelity

# Compile paper
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex